"""Authenticated scheduler client; no tokens, responses or secrets printed."""
import json
import os
import sys
import time
from urllib.parse import urlencode
from urllib.request import Request, urlopen


def main():
    kind = sys.argv[1] if len(sys.argv) > 1 else ''
    if kind not in ('forecast', 'review', 'configure', 'export'):
        raise SystemExit('Expected forecast, review, configure or export')
    base = os.environ['BOT_BASE_URL'].rstrip('/')
    if not base.startswith('https://'):
        raise SystemExit('HTTPS required')
    auth = {'Authorization': 'Bearer ' + os.environ['JOBS_SECRET'], 'Content-Type': 'application/json'}
    def call(path, post=False):
        req = Request(base + path, data=b'{}' if post else None, headers=auth)
        with urlopen(req, timeout=45) as r:
            return json.load(r)
    try:
        if kind == 'configure':
            call('/admin/configure-telegram', True)
            print('Telegram webhook and commands configured.')
            return
        if kind == 'export':
            data = call('/admin/export')
            with open('bot-export.json', 'w') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            print('Private export written to bot-export.json.')
            return
        job = call('/jobs/' + kind, True)
        deadline = time.monotonic() + 16 * 60
        while time.monotonic() < deadline:
            state = call('/admin/job?' + urlencode({'id': job['id']}))
            if state['status'] == 'done':
                print(kind + ' completed.')
                return
            if state['status'] == 'failed':
                raise RuntimeError('Job failed: ' + (state.get('error') or 'unknown category'))
            time.sleep(15)
        raise RuntimeError('Timed out waiting for completion; job may still be running. Check before retry.')
    except Exception as exc:
        # urllib exception strings may expose URL; show only exception class.
        print('Operation failed: ' + type(exc).__name__, file=sys.stderr)
        raise SystemExit(1) from None


if __name__ == '__main__':
    main()
