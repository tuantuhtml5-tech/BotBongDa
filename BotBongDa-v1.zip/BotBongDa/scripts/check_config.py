"""Validate environment without printing secrets or contacting paid APIs."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from bot.config import Config

try:
    Config.load()
except ValueError as error:
    print('Configuration invalid: ' + str(error))
    raise SystemExit(1)
print('Configuration valid. No external API calls made.')
