"""Run locally BEFORE configuring webhook. Does not acknowledge/drop updates."""
import json
import os
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from bot.http_client import request_json

try:
    token = os.environ.get('TELEGRAM_BOT_TOKEN')
    if not token:
        import getpass
        token = getpass.getpass('Bot token (hidden): ')
    base = 'https://api.telegram.org/bot' + token
    info = request_json(base + '/getWebhookInfo', {}, timeout=30)
    if not info.get('ok'):
        raise RuntimeError()
    if info['result'].get('url'):
        raise SystemExit('Webhook already active. This script will not change it.')
    result = request_json(base + '/getUpdates', {'timeout': 0, 'allowed_updates': ['message']}, timeout=30)
    if not result.get('ok'):
        raise RuntimeError()
    seen = set()
    for update in result['result']:
        msg = update.get('message', {})
        if msg.get('chat', {}).get('type') == 'private':
            pair = (msg.get('from', {}).get('id'), msg['chat']['id'])
            if pair not in seen:
                print(json.dumps({'user_id': pair[0], 'private_chat_id': pair[1]}))
                seen.add(pair)
    if not seen:
        print('Send /start to your new bot, then run this script again.')
    elif len(seen) > 1:
        print('Multiple users found: explicitly choose your own ID; do not guess.')
except Exception:
    raise SystemExit('Telegram lookup failed. Check token/network; no token was logged.') from None
