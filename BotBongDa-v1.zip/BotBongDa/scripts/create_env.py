"""Create a local .env interactively; never sends credentials anywhere."""
import getpass
import os
from pathlib import Path
import secrets

root = Path(__file__).resolve().parent.parent
path = root / '.env'
if path.exists():
    raise SystemExit('.env already exists; refusing to overwrite.')
values = {
    'TELEGRAM_BOT_TOKEN': getpass.getpass('Telegram bot token (hidden): ').strip(),
    'TELEGRAM_USER_ID': input('Your numeric Telegram user ID: ').strip(),
    'TELEGRAM_CHAT_ID': input('Private chat ID (usually same as user ID): ').strip(),
    'OPENAI_API_KEY': getpass.getpass('OpenAI API key (hidden): ').strip(),
    'BOT_BASE_URL': input('HTTPS public bot URL: ').strip().rstrip('/'),
    'JOBS_SECRET': secrets.token_urlsafe(32),
    'WEBHOOK_SECRET': secrets.token_urlsafe(32),
}
if any(not v or '\n' in v or '\r' in v or '#' in v for v in values.values()):
    raise SystemExit('Missing or invalid input; nothing written.')
content = (root / '.env.example').read_text()
for key, value in values.items():
    lines = content.splitlines()
    content = '\n'.join(key + '=' + value if line.startswith(key + '=') else line for line in lines) + '\n'
fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
with os.fdopen(fd, 'w') as out:
    out.write(content)
print('Created .env with private file permissions. Keep it out of Git and chat.')
