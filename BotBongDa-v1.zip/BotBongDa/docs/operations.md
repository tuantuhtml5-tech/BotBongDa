# Vận hành BotBongDa

## Luồng khởi động và quyền

Webhook chỉ chấp nhận đúng `WEBHOOK_SECRET`, đúng user ID và chat ID riêng tư đã cấu hình.
Tin nhắn được ghi SQLite trước khi Telegram nhận HTTP 200. Một worker xử lý hàng đợi.
Lệnh quản trị cần `Authorization: Bearer JOBS_SECRET`; không đưa secret vào URL.
`/healthz` công khai nhưng chỉ trả tình trạng sẵn sàng, không lộ dữ liệu.

Container khởi động để thiết lập quyền disk rồi hạ quyền xuống UID/GID 10001 trước khi chạy web.
Chạy 1 instance/1 process; không nhân bản để tránh claim lại tác vụ của process khác lúc startup.
Không dùng `python -m bot.entrypoint` với quyền root trên máy cá nhân; chỉ dùng entrypoint trong container.

## Secrets cần điền

| Nơi | Tên | Ý nghĩa |
|---|---|---|
| Dịch vụ web | TELEGRAM_BOT_TOKEN | Token của bot mới từ BotFather |
| Dịch vụ web | TELEGRAM_USER_ID | ID số của chính bạn |
| Dịch vụ web | TELEGRAM_CHAT_ID | ID chat riêng của bạn với bot |
| Dịch vụ web | OPENAI_API_KEY | API key có ngân sách phù hợp |
| Dịch vụ web | JOBS_SECRET | Chuỗi ngẫu nhiên dài >=32, giữ kín |
| Dịch vụ web | WEBHOOK_SECRET | Chuỗi khác JOBS_SECRET, >=32 ký tự |
| Dịch vụ web + GitHub Secrets | BOT_BASE_URL | URL HTTPS của dịch vụ |
| GitHub Secrets | JOBS_SECRET | Cùng giá trị ở dịch vụ web |
| GitHub Variable | BOT_SCHEDULE_ENABLED | `true` để bật tác vụ có thể phát sinh phí |

Các secrets không nằm trong code. Script `scripts/create_env.py` tạo `.env` cục bộ bằng nhập ẩn,
chỉ dành cho Docker Compose; trên Render điền vào Environment, không upload `.env` công khai.

## Lịch và hàng đợi

- Forecast: 15:17 Việt Nam; xét 24 giờ tiếp theo, bỏ trận quá sát giờ (<10 phút).
- Review: 08:17 Việt Nam; chỉ kiểm tra trận đã qua giờ khai cuộc ít nhất 3 giờ.
- Mỗi loại tác vụ tối đa một ID/ngày. Chạy lại workflow không tự tạo thêm dự đoán.
- Mặc định review tối đa 3 trận/lượt. Có backlog thì luân phiên để tránh trận chưa rõ chặn các trận khác.
- Nếu tác vụ failed, sửa nguyên nhân rồi POST `/admin/retry` với `{"id":"forecast:YYYY-MM-DD"}`
  hoặc `review:YYYY-MM-DD`. Tối đa 3 lần thử, cùng ID; không làm lại dự đoán gốc đã lưu.
- Chat `/dudoan` và `/danhgia` xếp việc; `/homnay` và `/ketqua` chỉ đọc báo cáo gần nhất.
- Report có thể dài, Telegram chia nhiều tin; gửi không dùng HTML/Markdown để tránh injection.
- Queue durable, khởi động lại sẽ lấy lại việc đang chạy. Có thể gửi lặp trả lời nếu process chết
  đúng sau khi Telegram nhận tin nhưng trước khi đánh dấu done (at-least-once delivery).
  Telegram không cung cấp idempotency key cho sendMessage; không tuyên bố exactly-once tuyệt đối.

## Giới hạn và xác minh

Model research và structured output được kiểm tra tách biệt. Hai URL có citation thuộc hai domain
khác nhau là điều kiện tối thiểu, không phải bằng chứng tự động rằng đúng trận/đúng kết quả.
Kết quả chấm là tự động có nguồn nhưng chưa phải oracle đáng tin tuyệt đối. Chưa có feed chính thức
được đối soát độc lập. Kiểm tra nguồn khi thấy bất thường; dữ liệu mâu thuẫn phải để chờ.

Dự đoán không được sửa/xóa qua app; kết quả chỉ được nhập một lần. Nếu phát hiện kết quả đã nhập sai,
**không sửa trực tiếp bằng SQL** để rồi gọi đó là bản gốc. Dừng review, lưu snapshot, lập hồ sơ đính chính
và bổ sung migration có nhật ký trước khi đưa lại vào thống kê. Bản đầu chưa có endpoint sửa kết quả.

Bài học auto chỉ cập nhật bảng `lessons` của bot. Dưới 3 hồ sơ: đề xuất; từ 3 hồ sơ: đưa vào ngữ cảnh
với nhãn thử nghiệm. Ngưỡng 3 chỉ là guardrail, không chứng minh quy luật; không fine-tune, không
thay prompt gốc/weights, không tự commit/sửa plugin ChatGPT. Đồng bộ plugin hiện chưa có API tích hợp.

## Sao lưu

- Định kỳ snapshot disk qua nền tảng hosting là backup đầy đủ (gồm queue, evidence, history).
- Với Docker/VPS, có thể dùng SQLite backup API trong container:

```bash
docker compose exec bot python -c "import sqlite3; s=sqlite3.connect('/data/bot.sqlite3'); d=sqlite3.connect('/data/backup.sqlite3'); s.backup(d); d.close(); s.close()"
```

- `/admin/export` xuất 10.000 dự đoán gần nhất, tối đa 30 bài học, kết quả/nguồn và thống kê.
  Nó **không** phải snapshot đầy đủ, không gồm hội thoại/hàng đợi. Xuất bằng workflow operation `export`
  chỉ được phép ở repo private; artifact giữ 7 ngày, sau đó tự tải về nơi riêng tư.
- Không lưu snapshot vào public Git hoặc gửi token trong hội thoại Telegram.
- Khôi phục: tắt bot, thay disk DB bằng snapshot phù hợp, đặt quyền UID/GID 10001 và khởi động lại.
  Không ghi đè file SQLite đang mở. Các tác vụ đang chạy có thể được phát lại sau restore.

## Kiểm tra thật sau triển khai

1. `/healthz`: web + DB trả OK.
2. Workflow `configure`: webhook và commands được Telegram chấp nhận.
3. Telegram `/start`: chỉ tài khoản của bạn trả lời; tài khoản khác bị bỏ qua.
4. Workflow `forecast`: chờ done rồi `/homnay`; thiếu nguồn thì không có dự đoán là hành vi hợp lệ.
5. Sau trận chạy `review`: xác minh URL, tỷ số, line, thời điểm trước trận và kết quả chấm.
6. Restart server rồi `/homnay`, `/ketqua`: dữ liệu phải còn.
7. Đặt `BOT_SCHEDULE_ENABLED=true` khi chấp nhận phí vận hành/API.

Không có test live hoàn thành trước khi chủ tài khoản cung cấp credentials và hosting.

## Nguồn kỹ thuật

- OpenAI Responses/web search: https://developers.openai.com/api/docs/guides/tools-web-search
- Structured outputs: https://developers.openai.com/api/docs/guides/structured-outputs
- Telegram Bot API: https://core.telegram.org/bots/api
- GitHub Actions schedule: https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax
- GitHub schedule delays: https://docs.github.com/en/actions/how-tos/troubleshoot-workflows
