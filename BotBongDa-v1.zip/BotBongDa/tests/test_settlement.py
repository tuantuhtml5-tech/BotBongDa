import unittest
from bot.settlement import settle


class SettlementTests(unittest.TestCase):
    def test_quarter_totals(self):
        cases = [('over', 3.25, 3, 'half_loss', -.5), ('under', 3.25, 3, 'half_win', .45),
                 ('over', 3.5, 3, 'loss', -1), ('under', 3.5, 3, 'win', .9),
                 ('over', 4.25, 4, 'half_loss', -.5), ('over', 3, 3, 'push', 0),
                 ('over', 2.75, 3, 'half_win', .45), ('under', 2.75, 3, 'half_loss', -.5)]
        for side, line, goals, outcome, net in cases:
            with self.subTest(side=side, line=line, goals=goals):
                s = settle('total', side, line, goals, 0, 1.9)
                self.assertEqual(s['outcome'], outcome)
                self.assertAlmostEqual(s['net_units'], net)

    def test_handicap_and_1x2(self):
        self.assertEqual(settle('handicap', 'home', -1.25, 2, 1, 2)['outcome'], 'half_loss')
        self.assertEqual(settle('handicap', 'away', 1.25, 2, 1, 2)['outcome'], 'half_win')
        self.assertEqual(settle('1x2', 'home', None, 2, 1)['outcome'], 'win')
        self.assertIsNone(settle('1x2', 'home', None, 2, 1)['net_units'])

    def test_all_quarter_lines_are_zero_sum_at_even_odds(self):
        for q in range(1, 29):
            for h in range(8):
                for a in range(8):
                    over = settle('total', 'over', q / 4, h, a, 2)['net_units']
                    under = settle('total', 'under', q / 4, h, a, 2)['net_units']
                    self.assertAlmostEqual(over + under, 0)
                    home = settle('handicap', 'home', -q / 4, h, a, 2)['net_units']
                    away = settle('handicap', 'away', q / 4, h, a, 2)['net_units']
                    self.assertAlmostEqual(home + away, 0)

    def test_invalid_values_rejected(self):
        for line in (3.1, -1, float('nan'), float('inf')):
            with self.assertRaises(ValueError):
                settle('total', 'over', line, 1, 1)
        for odds in (0, 1, float('nan'), float('inf')):
            with self.assertRaises(ValueError):
                settle('total', 'over', 2.5, 1, 1, odds)
        with self.assertRaises(ValueError):
            settle('1x2', 'home', None, True, 1)
