import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from bot.ai import AI, RESULT_SCHEMA
from bot.store import Store
from bot.http_client import RemoteError
from test_service import config


class AITests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.cfg = config(str(Path(self.tmp.name) / 'test.sqlite'))
        self.store = Store(self.cfg.db_path)
        self.ai = AI(self.cfg, self.store)
    def tearDown(self):
        self.tmp.cleanup()

    @patch('bot.ai.request_json')
    def test_research_requires_citations_and_no_api_secret_in_prompt(self, req):
        req.return_value = {'status': 'completed', 'output': [{'type': 'message', 'content': [
            {'type': 'output_text', 'text': 'result', 'annotations': []}]}]}
        with self.assertRaises(RemoteError):
            self.ai.research('test')
        req.return_value['output'][0]['content'][0]['annotations'] = [
            {'type': 'url_citation', 'url': 'https://news.example/report', 'title': 'test'}]
        research = self.ai.research('test')
        self.assertIn('https://news.example/report', research['sources'])
        payload = req.call_args.args[1]
        self.assertEqual(payload['tools'], [{'type': 'web_search'}])
        self.assertEqual(payload['tool_choice'], 'required')
        self.assertFalse(payload['store'])
        self.assertNotIn('TELEGRAM_BOT_TOKEN', payload['input'])

    @patch('bot.ai.request_json')
    def test_truncated_research_fails_closed(self, req):
        req.return_value = {'status': 'incomplete', 'output': []}
        with self.assertRaises(RemoteError):
            self.ai.research('test')
