import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from bot.store import Store


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Store(str(Path(self.tmp.name) / 'test.sqlite'))
    def tearDown(self):
        self.tmp.cleanup()

    def test_enqueue_and_claim_exactly_once(self):
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(lambda _: self.db.enqueue('id', 'chat', {'text': 'hello'}), range(20)))
        self.assertEqual(sum(results), 1)
        self.assertIsNotNone(self.db.claim())
        self.assertIsNone(self.db.claim())
        self.db.finish('id')

    def test_api_budget_atomic(self):
        def reserve(_):
            try:
                self.db.reserve_api('2026-11-05', 3)
                return True
            except RuntimeError:
                return False
        with ThreadPoolExecutor(max_workers=8) as pool:
            self.assertEqual(sum(pool.map(reserve, range(20))), 3)

    def test_forecast_immutable_and_no_fake_lesson_evidence(self):
        p = {'market': 'total'}
        self.assertTrue(self.db.save_forecast('x', '2026-11-07T00:00:00+00:00', p, {}, 'test', '1'))
        self.assertFalse(self.db.save_forecast('x', 'later', p, {}, 'test', '2'))
        with self.assertRaises(sqlite3.IntegrityError):
            with self.db.conn() as db:
                db.execute("UPDATE forecasts SET prediction='{}'")
        with self.assertRaises(sqlite3.IntegrityError):
            with self.db.conn() as db:
                db.execute('DELETE FROM forecasts')
        self.assertEqual(self.db.propose_lesson('No fake evidence', [98, 99, 100]), 'proposed')
        self.assertEqual(json.loads(self.db.lessons()[0]['evidence_ids']), [])

    def test_recovery_and_stats(self):
        self.db.enqueue('x', 'chat', {})
        self.db.claim()
        recovered = Store(self.db.path)
        self.assertIsNotNone(recovered.claim())
        self.db.save_forecast('x', '2026-01-01T00:00:00+00:00', {'market': 'total'}, {}, 'test', '1')
        self.db.save_result(1, {}, {'outcome': 'half_loss', 'net_units': None})
        self.assertEqual(self.db.stats()['total']['half_loss'], 1)
        self.assertEqual(self.db.stats()['total']['priced'], 0)
        self.assertFalse(self.db.save_result(1, {'changed': True}, {}))
