from copy import deepcopy
from datetime import datetime, timedelta, timezone
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch
from bot.config import Config
from bot.store import Store
from bot.service import Service, validate_pick, evidence_ok


def config(path):
    return Config('fake', 123, 123, 'fake', 'j' * 40, 'w' * 40, 'https://bot.example', db_path=path)


def pick():
    return {'home': 'Team A', 'away': 'Team B', 'competition': 'Test League', 'season': '2026/27',
            'kickoff': (datetime.now(timezone.utc) + timedelta(hours=10)).isoformat(),
            'fixture_verified': True, 'market': 'total', 'selection': 'over', 'line': 2.5,
            'odds': None, 'odds_source': None, 'line_kind': 'reference', 'confidence': 'low',
            'score': '2–1', 'reason': 'Test only', 'risk': 'Test only', 'change_conditions': 'Test only',
            'sources': ['https://league.example/fixture', 'https://news.example/fixture']}


def research():
    return {'text': 'Test research only', 'sources': {'https://league.example/fixture': 'League',
            'https://news.example/fixture': 'News'}, 'retrieved_at': datetime.now(timezone.utc).isoformat()}


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.cfg = config(str(Path(self.tmp.name) / 'test.sqlite'))
        self.store = Store(self.cfg.db_path)
        self.ai = Mock()
        self.ai.research.return_value = research()
        self.telegram = Mock()
        self.service = Service(self.cfg, self.store, self.telegram, self.ai)
    def tearDown(self):
        self.tmp.cleanup()

    def test_stale_and_uncited_predictions_rejected(self):
        p = pick()
        validate_pick(p, research(), datetime.now(timezone.utc))
        p['kickoff'] = datetime.now(timezone.utc).isoformat()
        with self.assertRaises(ValueError):
            validate_pick(p, research(), datetime.now(timezone.utc))
        p = pick(); p['sources'] += ['https://invented.example']
        with self.assertRaises(ValueError):
            validate_pick(p, research(), datetime.now(timezone.utc))
        p = pick(); p['odds'] = 1.9
        with self.assertRaises(ValueError):
            validate_pick(p, research(), datetime.now(timezone.utc))
        self.assertFalse(evidence_ok(['https://a.co.uk/x', 'https://www.a.co.uk/y'], {'sources': {'https://a.co.uk/x': '', 'https://www.a.co.uk/y': ''}}))

    @patch('bot.service.schedule_text', return_value='offline test schedule')
    def test_forecast_saved_once_silent_and_recoverable(self, _):
        p = pick()
        self.ai.structure.return_value = {'picks': [p], 'notes': 'Test only'}
        self.service.forecast()
        self.service.forecast()
        self.assertEqual(len(self.store.forecasts()), 1)
        self.telegram.send.assert_not_called()
        self.assertIn('Test League', self.service.chat('/homnay'))

    def test_wrong_result_identity_or_scope_not_settled(self):
        p = pick(); p['kickoff'] = (datetime.now(timezone.utc) - timedelta(days=1)).isoformat()
        self.store.save_forecast('x', p['kickoff'], p, research(), 'test', '1')
        result = {k: p[k] for k in ('home', 'away', 'competition', 'season', 'kickoff')}
        result.update(status='finished', home_goals=2, away_goals=1, scope='other',
                      sources=p['sources'], explanation='Test')
        self.ai.structure.return_value = result
        self.service.evaluate()
        self.assertIsNone(self.store.forecasts()[0]['result'])
        result['scope'] = '90min'; result['home'] = 'Wrong Team'
        self.service.evaluate()
        self.assertIsNone(self.store.forecasts()[0]['result'])

    def test_verified_result_settled_and_no_odds_no_profit(self):
        p = pick(); p['kickoff'] = (datetime.now(timezone.utc) - timedelta(days=1)).isoformat()
        self.store.save_forecast('x', p['kickoff'], p, research(), 'test', '1')
        result = {k: p[k] for k in ('home', 'away', 'competition', 'season', 'kickoff')}
        result.update(status='finished', home_goals=2, away_goals=1, scope='90min', sources=p['sources'], explanation='Test')
        self.ai.structure.return_value = result
        self.ai.call.return_value = {'lessons': [{'text': 'Proposed test lesson', 'evidence_ids': [1]}]}
        self.service.evaluate()
        self.assertEqual(self.store.stats()['total']['win'], 1)
        self.assertEqual(self.store.stats()['total']['priced'], 0)
        self.assertEqual(self.store.lessons()[0]['status'], 'proposed')
        self.service.evaluate()
        self.assertEqual(self.store.stats()['total']['matches'], 1)
