import json
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from http.server import ThreadingHTTPServer
from unittest.mock import Mock
from bot.server import App, handler_for
from bot.store import Store
from test_service import config


class WebhookTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.cfg = config(str(Path(self.tmp.name) / 'test.sqlite'))
        self.store = Store(self.cfg.db_path)
        self.service = Mock()
        self.service.chat.return_value = 'hello'
        self.telegram = Mock()
        self.app = App(self.cfg, self.store, self.telegram, self.service)
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), handler_for(self.app))
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base = 'http://127.0.0.1:' + str(self.server.server_port)
    def tearDown(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join()
        self.tmp.cleanup()
    def post(self, path, data, headers=None):
        req = Request(self.base + path, data=json.dumps(data).encode(), headers=headers or {})
        with urlopen(req, timeout=3) as response:
            return json.load(response)
    def update(self, uid=123):
        return {'update_id': 17, 'message': {'from': {'id': uid}, 'chat': {'id': 123, 'type': 'private'}, 'text': '/homnay'}}

    def test_auth_and_idempotent_delivery(self):
        with self.assertRaises(HTTPError) as e:
            self.post('/telegram/webhook', self.update())
        self.assertEqual(e.exception.code, 401)
        headers = {'X-Telegram-Bot-Api-Secret-Token': self.cfg.webhook_secret}
        self.post('/telegram/webhook', self.update(666), headers)
        self.assertIsNone(self.store.claim())
        self.post('/telegram/webhook', self.update(), headers)
        self.post('/telegram/webhook', self.update(), headers)
        self.assertTrue(self.app.work_once())
        self.assertFalse(self.app.work_once())
        self.telegram.send.assert_called_once_with('hello')

    def test_job_auth_and_day_dedup(self):
        with self.assertRaises(HTTPError):
            self.post('/jobs/forecast', {})
        auth = {'Authorization': 'Bearer ' + self.cfg.jobs_secret}
        self.assertTrue(self.post('/jobs/forecast', {}, auth)['created'])
        self.assertFalse(self.post('/jobs/forecast', {}, auth)['created'])
        self.app.work_once()
        self.service.forecast.assert_called_once()

    def test_failures_do_not_leak_secret(self):
        self.service.chat.side_effect = RuntimeError('PRIVATE_TOKEN')
        self.store.enqueue('x', 'chat', {'text': 'hello'})
        self.app.work_once()
        with self.store.conn() as db:
            row = db.execute('SELECT * FROM jobs').fetchone()
        self.assertEqual(row['status'], 'failed')
        self.assertNotIn('PRIVATE_TOKEN', row['error'])
        self.assertNotIn('PRIVATE_TOKEN', self.telegram.send.call_args.args[0])
