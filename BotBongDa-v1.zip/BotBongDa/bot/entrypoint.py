"""Initialize persistent volume permissions, then permanently drop root privileges."""
import os
from pathlib import Path


def main():
    directory = Path(os.environ.get('DB_PATH', '/data/bot.sqlite3')).parent
    directory.mkdir(parents=True, exist_ok=True)
    if os.geteuid() == 0:
        # Container mounts may arrive owned by root. Only touch the configured data directory.
        os.chown(directory, 10001, 10001)
        os.chmod(directory, 0o700)
        for path in directory.glob('bot.sqlite3*'):
            if path.is_file() and not path.is_symlink():
                os.chown(path, 10001, 10001)
                os.chmod(path, 0o600)
        os.setgroups([])
        os.setgid(10001)
        os.setuid(10001)
    from .server import main as serve
    serve()


if __name__ == '__main__':
    main()
