"""Pure settlement arithmetic; normalized decimal odds, equal notional halves."""
from decimal import Decimal, InvalidOperation


def decimal_value(value):
    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError('Invalid number') from None


def settle(market, selection, line, home, away, odds=None):
    if any(type(n) is not int or n < 0 or n > 50 for n in (home, away)):
        raise ValueError('Invalid score')
    price = None if odds is None else decimal_value(odds)
    if price is not None and (not price.is_finite() or price <= 1 or price > 1000):
        raise ValueError('Invalid decimal odds')
    if market == '1x2':
        if selection not in ('home', 'draw', 'away') or line is not None:
            raise ValueError('Invalid 1X2')
        actual = 'home' if home > away else 'away' if away > home else 'draw'
        pieces = [1 if selection == actual else -1]
    elif market in ('total', 'handicap'):
        x = decimal_value(line)
        if not x.is_finite() or x * 4 != (x * 4).to_integral() or abs(x) > 20:
            raise ValueError('Invalid quarter line')
        split = [x] if x * 2 == (x * 2).to_integral() else [x - Decimal('.25'), x + Decimal('.25')]
        if market == 'total':
            if selection not in ('over', 'under') or x < 0:
                raise ValueError('Invalid total')
            values = [(Decimal(home + away) - n) * (1 if selection == 'over' else -1) for n in split]
        else:
            if selection not in ('home', 'away'):
                raise ValueError('Invalid handicap')
            difference = home - away if selection == 'home' else away - home
            values = [Decimal(difference) + n for n in split]
        pieces = [(v > 0) - (v < 0) for v in values]
    else:
        raise ValueError('Unknown market')
    value = sum(pieces) / len(pieces)
    outcome = {1: 'win', .5: 'half_win', 0: 'push', -.5: 'half_loss', -1: 'loss'}[value]
    net = None if price is None else float(sum((price - 1 if p == 1 else Decimal(p)) for p in pieces) / len(pieces))
    return {'outcome': outcome, 'net_units': net}
