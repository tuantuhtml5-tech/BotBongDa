import json
import sqlite3
from datetime import datetime, timezone
from contextlib import contextmanager


def now():
    return datetime.now(timezone.utc).isoformat()


def dumps(value):
    return json.dumps(value, ensure_ascii=False)


class Store:
    def __init__(self, path):
        self.path = path
        with self.conn() as db:
            db.executescript('''
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS jobs (
              id TEXT PRIMARY KEY, kind TEXT NOT NULL, payload TEXT NOT NULL,
              status TEXT NOT NULL DEFAULT 'queued', attempts INTEGER NOT NULL DEFAULT 0,
              created TEXT NOT NULL, error TEXT);
            CREATE TABLE IF NOT EXISTS forecasts (
              id INTEGER PRIMARY KEY, match_key TEXT NOT NULL UNIQUE, created TEXT NOT NULL,
              kickoff TEXT NOT NULL, prediction TEXT NOT NULL, research TEXT NOT NULL,
              model TEXT NOT NULL, method_version TEXT NOT NULL);
            CREATE TRIGGER IF NOT EXISTS immutable_forecasts_update BEFORE UPDATE ON forecasts
              BEGIN SELECT RAISE(ABORT, 'forecasts are immutable'); END;
            CREATE TRIGGER IF NOT EXISTS immutable_forecasts_delete BEFORE DELETE ON forecasts
              BEGIN SELECT RAISE(ABORT, 'forecasts are immutable'); END;
            CREATE TABLE IF NOT EXISTS results (
              forecast_id INTEGER PRIMARY KEY REFERENCES forecasts(id), created TEXT NOT NULL,
              result TEXT NOT NULL, settlement TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS reviews (
              id INTEGER PRIMARY KEY, forecast_id INTEGER NOT NULL, created TEXT NOT NULL,
              evidence TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS lessons (
              id INTEGER PRIMARY KEY, created TEXT NOT NULL, text TEXT NOT NULL UNIQUE,
              evidence_ids TEXT NOT NULL, status TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS reports (
              id INTEGER PRIMARY KEY, kind TEXT NOT NULL, created TEXT NOT NULL, text TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS messages (
              id INTEGER PRIMARY KEY, created TEXT NOT NULL, role TEXT NOT NULL, text TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS api_usage (day TEXT PRIMARY KEY, calls INTEGER NOT NULL);
            ''')
            db.execute("UPDATE jobs SET status='queued' WHERE status='running'")

    @contextmanager
    def conn(self):
        db = sqlite3.connect(self.path, timeout=30)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def enqueue(self, jid, kind, payload):
        with self.conn() as db:
            cur = db.execute('INSERT OR IGNORE INTO jobs(id,kind,payload,created) VALUES(?,?,?,?)',
                             (jid, kind, dumps(payload), now()))
            return cur.rowcount == 1

    def claim(self):
        with self.conn() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY created,id LIMIT 1").fetchone()
            if row:
                db.execute("UPDATE jobs SET status='running',attempts=attempts+1 WHERE id=?", (row['id'],))
                return dict(row)

    def finish(self, jid, error=None):
        with self.conn() as db:
            db.execute('UPDATE jobs SET status=?,error=? WHERE id=?',
                       ('failed' if error else 'done', error, jid))

    def reserve_api(self, day, limit):
        with self.conn() as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute('INSERT OR IGNORE INTO api_usage VALUES(?,0)', (day,))
            n = db.execute('SELECT calls FROM api_usage WHERE day=?', (day,)).fetchone()[0]
            if n >= limit:
                raise RuntimeError('Đã chạm giới hạn lượt API trong ngày.')
            db.execute('UPDATE api_usage SET calls=calls+1 WHERE day=?', (day,))

    def save_forecast(self, key, kickoff, prediction, research, model, version):
        with self.conn() as db:
            cur = db.execute('''INSERT OR IGNORE INTO forecasts
              (match_key,created,kickoff,prediction,research,model,method_version) VALUES(?,?,?,?,?,?,?)''',
                             (key, now(), kickoff, dumps(prediction), dumps(research), model, version))
            return cur.rowcount == 1

    def forecasts(self, pending=False, limit=30):
        with self.conn() as db:
            query = 'SELECT f.*,r.result,r.settlement FROM forecasts f LEFT JOIN results r ON f.id=r.forecast_id'
            if pending:
                query += ' WHERE r.forecast_id IS NULL'
            return [dict(r) for r in db.execute(query + ' ORDER BY f.created DESC LIMIT ?', (limit,))]

    def save_result(self, fid, result, settlement):
        with self.conn() as db:
            return db.execute('INSERT OR IGNORE INTO results VALUES(?,?,?,?)',
                              (fid, now(), dumps(result), dumps(settlement))).rowcount == 1

    def review(self, fid, evidence):
        with self.conn() as db:
            db.execute('INSERT INTO reviews(forecast_id,created,evidence) VALUES(?,?,?)',
                       (fid, now(), dumps(evidence)))

    def propose_lesson(self, text, evidence_ids):
        ids = sorted(set(evidence_ids))
        with self.conn() as db:
            valid = [i for i in ids if db.execute('SELECT 1 FROM results WHERE forecast_id=?', (i,)).fetchone()]
            status = 'active' if len(valid) >= 3 else 'proposed'
            db.execute('''INSERT OR IGNORE INTO lessons(created,text,evidence_ids,status) VALUES(?,?,?,?)''',
                       (now(), text[:2000], dumps(valid), status))
            return status

    def lessons(self):
        with self.conn() as db:
            return [dict(r) for r in db.execute('SELECT * FROM lessons ORDER BY id DESC LIMIT 30')]

    def report(self, kind, text):
        with self.conn() as db:
            db.execute('INSERT INTO reports(kind,created,text) VALUES(?,?,?)', (kind, now(), text))

    def latest(self, kind):
        with self.conn() as db:
            row = db.execute('SELECT * FROM reports WHERE kind=? ORDER BY id DESC LIMIT 1', (kind,)).fetchone()
            return dict(row) if row else None

    def message(self, role, text):
        with self.conn() as db:
            db.execute('INSERT INTO messages(created,role,text) VALUES(?,?,?)', (now(), role, text[:12000]))
            db.execute('DELETE FROM messages WHERE id NOT IN (SELECT id FROM messages ORDER BY id DESC LIMIT 20)')

    def history(self):
        with self.conn() as db:
            return [dict(r) for r in db.execute('SELECT role,text FROM messages ORDER BY id')]

    def stats(self):
        with self.conn() as db:
            rows = db.execute('SELECT f.prediction,r.settlement FROM forecasts f JOIN results r ON f.id=r.forecast_id').fetchall()
            out = {}
            for row in rows:
                market = json.loads(row[0])['market']
                s = json.loads(row[1])
                group = out.setdefault(market, {'matches': 0, 'win': 0, 'loss': 0, 'push': 0,
                                                'half_win': 0, 'half_loss': 0, 'priced': 0, 'net_units': 0.0})
                group['matches'] += 1
                group[s['outcome']] += 1
                if s['net_units'] is not None:
                    group['priced'] += 1
                    group['net_units'] += s['net_units']
            return out
