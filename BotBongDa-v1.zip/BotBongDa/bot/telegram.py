from .http_client import request_json, RemoteError


class Telegram:
    def __init__(self, cfg):
        self.cfg = cfg

    def call(self, method, payload):
        result = request_json(f'https://api.telegram.org/bot{self.cfg.token}/{method}', payload, timeout=30)
        if not result.get('ok'):
            raise RemoteError('Telegram rejected request')
        return result.get('result')

    def send(self, text):
        # Plain text avoids Telegram HTML/Markdown injection and broken escaping.
        # 1,800 Unicode code points fit below 4,096 UTF-16 units even with emoji.
        for start in range(0, len(text), 1800):
            self.call('sendMessage', {'chat_id': self.cfg.chat_id, 'text': text[start:start + 1800],
                                     'link_preview_options': {'is_disabled': True}})

    def configure(self):
        self.call('setWebhook', {'url': self.cfg.base_url + '/telegram/webhook',
                                'secret_token': self.cfg.webhook_secret,
                                'allowed_updates': ['message'], 'max_connections': 1,
                                'drop_pending_updates': False})
        self.call('setMyCommands', {'commands': [
            {'command': 'homnay', 'description': 'Xem bản dự đoán đã lưu'},
            {'command': 'ketqua', 'description': 'Xem đánh giá sau trận'},
            {'command': 'kinhnghiem', 'description': 'Bài học và trạng thái bằng chứng'},
            {'command': 'thongke', 'description': 'Thống kê các dự đoán đã chấm'},
            {'command': 'trangthai', 'description': 'Trạng thái hệ thống'},
            {'command': 'help', 'description': 'Hướng dẫn sử dụng'}]})
