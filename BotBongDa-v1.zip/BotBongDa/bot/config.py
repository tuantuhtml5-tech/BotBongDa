from dataclasses import dataclass
import os
from pathlib import Path


@dataclass(frozen=True)
class Config:
    token: str
    user_id: int
    chat_id: int
    api_key: str
    jobs_secret: str
    webhook_secret: str
    base_url: str
    db_path: str = '/data/bot.sqlite3'
    model: str = 'gpt-6-astra'
    max_calls: int = 30
    notify: bool = False
    max_picks: int = 3
    review_batch: int = 3
    port: int = 8080

    @classmethod
    def load(cls):
        required = ['TELEGRAM_BOT_TOKEN', 'TELEGRAM_USER_ID', 'TELEGRAM_CHAT_ID',
                    'OPENAI_API_KEY', 'JOBS_SECRET', 'WEBHOOK_SECRET', 'BOT_BASE_URL']
        missing = [k for k in required if not os.environ.get(k)]
        if missing:
            raise ValueError('Missing configuration: ' + ', '.join(missing))
        if not os.environ['BOT_BASE_URL'].startswith('https://'):
            raise ValueError('BOT_BASE_URL must use HTTPS')
        for k in ['JOBS_SECRET', 'WEBHOOK_SECRET']:
            if len(os.environ[k]) < 32:
                raise ValueError(k + ' must have at least 32 characters')
        if os.environ['JOBS_SECRET'] == os.environ['WEBHOOK_SECRET']:
            raise ValueError('Use different job and webhook secrets')
        c = cls(os.environ['TELEGRAM_BOT_TOKEN'], int(os.environ['TELEGRAM_USER_ID']),
                int(os.environ['TELEGRAM_CHAT_ID']), os.environ['OPENAI_API_KEY'],
                os.environ['JOBS_SECRET'], os.environ['WEBHOOK_SECRET'],
                os.environ['BOT_BASE_URL'].rstrip('/'), os.getenv('DB_PATH', '/data/bot.sqlite3'),
                os.getenv('OPENAI_MODEL', 'gpt-6-astra'), int(os.getenv('MAX_API_CALLS_PER_DAY', '30')),
                os.getenv('NOTIFY_REPORTS', 'false').lower() == 'true',
                int(os.getenv('MAX_PICKS', '3')), int(os.getenv('MAX_REVIEW_BATCH', '3')),
                int(os.getenv('PORT', '8080')))
        if c.user_id <= 0 or c.chat_id <= 0:
            raise ValueError('Only a positive user ID and private chat ID are supported')
        if not 1 <= c.max_picks <= 3 or not 1 <= c.review_batch <= 10 or not 2 <= c.max_calls <= 200:
            raise ValueError('Invalid limits')
        Path(c.db_path).parent.mkdir(parents=True, exist_ok=True)
        return c
