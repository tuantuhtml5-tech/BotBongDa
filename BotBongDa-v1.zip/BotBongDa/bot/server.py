import hmac
import json
import logging
import signal
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs
from datetime import datetime
from .config import Config
from .store import Store, dumps
from .telegram import Telegram
from .service import Service, TZ

LOG = logging.getLogger('bot')


class App:
    def __init__(self, cfg, store=None, telegram=None, service=None):
        self.cfg = cfg
        self.store = store or Store(cfg.db_path)
        self.telegram = telegram or Telegram(cfg)
        self.service = service or Service(cfg, self.store, self.telegram)
        self.stop = threading.Event()

    def allowed(self, update):
        m = update.get('message')
        return (isinstance(m, dict) and isinstance(m.get('chat'), dict)
                and isinstance(m.get('from'), dict) and m['chat'].get('type') == 'private'
                and m.get('chat', {}).get('id') == self.cfg.chat_id
                and m.get('from', {}).get('id') == self.cfg.user_id
                and isinstance(m.get('text'), str) and len(m['text']) <= 6000)

    def work_once(self):
        job = self.store.claim()
        if not job:
            return False
        try:
            if job['kind'] == 'chat':
                data = json.loads(job['payload'])
                reply = self.service.chat(data['text'])
                self.telegram.send(reply)
            elif job['kind'] == 'forecast':
                self.service.forecast()
            elif job['kind'] == 'review':
                self.service.evaluate()
            else:
                raise ValueError('Unknown job')
            self.store.finish(job['id'])
        except Exception as exc:
            # No raw exception/traceback or payload: URLs can contain bot tokens.
            category = type(exc).__name__
            self.store.finish(job['id'], category)
            LOG.error('Job failed: kind=%s category=%s', job['kind'], category)
            if job['kind'] == 'chat' or self.cfg.notify:
                try:
                    self.telegram.send('Chưa hoàn thành tác vụ (' + category + '). '
                                       'Không tạo dữ liệu thay thế. Kiểm tra /trangthai; quản trị viên có thể thử lại.')
                except Exception:
                    LOG.error('Unable to deliver error notification')
        return True

    def worker(self):
        while not self.stop.is_set():
            try:
                if not self.work_once():
                    self.stop.wait(1)
            except Exception:
                LOG.error('Worker storage unavailable; retrying without disclosing data')
                self.stop.wait(10)


def handler_for(app):
    class Handler(BaseHTTPRequestHandler):
        server_version = 'BotBongDa'

        def setup(self):
            super().setup()
            self.connection.settimeout(20)

        def log_message(self, fmt, *args):
            # Do not log request URLs, bodies, headers or secrets.
            pass

        def respond(self, status, data):
            body = dumps(data).encode()
            self.send_response(status)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(body)

        def authorized(self, header, secret):
            value = self.headers.get(header, '')
            return hmac.compare_digest(value.encode(), secret.encode())

        def do_GET(self):
            parsed = urlsplit(self.path)
            if parsed.path == '/healthz':
                try:
                    with app.store.conn() as db:
                        db.execute('SELECT 1').fetchone()
                    return self.respond(200, {'ok': True})
                except Exception:
                    return self.respond(503, {'ok': False})
            if parsed.path.startswith('/admin/'):
                if not self.authorized('Authorization', 'Bearer ' + app.cfg.jobs_secret):
                    return self.respond(401, {'error': 'unauthorized'})
                if parsed.path == '/admin/job':
                    jid = parse_qs(parsed.query).get('id', [''])[0]
                    with app.store.conn() as db:
                        row = db.execute('SELECT id,kind,status,attempts,error FROM jobs WHERE id=?', (jid,)).fetchone()
                    return self.respond(200 if row else 404, dict(row) if row else {'error': 'not_found'})
                if parsed.path == '/admin/export':
                    # Export excludes chat messages and secrets. Treat as private data regardless.
                    return self.respond(200, {'version': 1, 'forecasts': app.store.forecasts(limit=10000),
                                              'lessons': app.store.lessons(), 'stats': app.store.stats()})
            self.respond(404, {'error': 'not_found'})

        def do_POST(self):
            try:
                size = int(self.headers.get('Content-Length', '0'))
            except ValueError:
                return self.respond(400, {'error': 'invalid_length'})
            if not 0 <= size <= 65536:
                return self.respond(413, {'error': 'too_large'})
            path = urlsplit(self.path).path
            if path == '/telegram/webhook':
                if not self.authorized('X-Telegram-Bot-Api-Secret-Token', app.cfg.webhook_secret):
                    return self.respond(401, {'error': 'unauthorized'})
                try:
                    update = json.loads(self.rfile.read(size))
                    if not isinstance(update, dict):
                        raise ValueError()
                    uid = update.get('update_id')
                    if type(uid) is not int or uid < 0:
                        raise ValueError()
                except (ValueError, TypeError):
                    return self.respond(400, {'error': 'invalid_update'})
                # Persist before acknowledgement; reject other users without disclosing bot state.
                if app.allowed(update):
                    app.store.enqueue('telegram:' + str(uid), 'chat', {'text': update['message']['text']})
                return self.respond(200, {'ok': True})
            if path.startswith(('/jobs/', '/admin/')):
                if not self.authorized('Authorization', 'Bearer ' + app.cfg.jobs_secret):
                    return self.respond(401, {'error': 'unauthorized'})
                try:
                    body = json.loads(self.rfile.read(size) or b'{}')
                    if not isinstance(body, dict):
                        raise ValueError()
                except ValueError:
                    return self.respond(400, {'error': 'invalid_json'})
                if path in ('/jobs/forecast', '/jobs/review'):
                    kind = path.rsplit('/', 1)[1]
                    jid = kind + ':' + datetime.now(TZ).date().isoformat()
                    created = app.store.enqueue(jid, kind, {})
                    return self.respond(202, {'id': jid, 'created': created})
                if path == '/admin/retry':
                    jid = body.get('id')
                    if not isinstance(jid, str):
                        return self.respond(400, {'error': 'id_required'})
                    with app.store.conn() as db:
                        cur = db.execute("UPDATE jobs SET status='queued',error=NULL WHERE id=? AND status='failed' AND attempts<3", (jid,))
                    return self.respond(200, {'queued': cur.rowcount == 1})
                if path == '/admin/configure-telegram':
                    try:
                        app.telegram.configure()
                        return self.respond(200, {'ok': True})
                    except Exception:
                        return self.respond(502, {'error': 'telegram_configuration_failed'})
            self.respond(404, {'error': 'not_found'})
    return Handler


def main():
    logging.basicConfig(level=logging.INFO, format='%(levelname)s %(message)s')
    try:
        cfg = Config.load()
    except ValueError as exc:
        raise SystemExit(str(exc)) from None
    app = App(cfg)
    server = ThreadingHTTPServer(('0.0.0.0', cfg.port), handler_for(app))
    server.daemon_threads = True
    server.timeout = 2
    # Socket read deadline mitigates stuck clients. Deploy behind an HTTPS reverse proxy.
    server.socket.settimeout(30)
    thread = threading.Thread(target=app.worker, daemon=True)
    thread.start()
    def stop(*_):
        app.stop.set()
        threading.Thread(target=server.shutdown, daemon=True).start()
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    LOG.info('Bot server ready on port %s', cfg.port)
    try:
        server.serve_forever()
    finally:
        app.stop.set()
        # Let an in-flight API operation finish before exit when host permits.
        thread.join(timeout=25)
        server.server_close()


if __name__ == '__main__':
    main()
