import json
import urllib.request
import urllib.error


class RemoteError(RuntimeError):
    pass


def request_json(url, payload=None, headers=None, timeout=180):
    data = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json', **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            raw = response.read(4_000_001)
            if len(raw) > 4_000_000:
                raise RemoteError('Remote response too large')
            return json.loads(raw)
    except urllib.error.HTTPError as exc:
        # Never expose exception URLs: Telegram token is embedded in its URL.
        raise RemoteError(f'Remote HTTP {exc.code}') from None
    except (OSError, ValueError):
        raise RemoteError('Remote connection or JSON error') from None
